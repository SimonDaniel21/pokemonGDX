<?xml version="1.0" encoding="UTF-8"?>
<tileset name="Pokemon Gold" tilewidth="16" tileheight="16" tilecount="2144" columns="8">
 <image source="tileset-shinygold.png" width="128" height="4300"/>
</tileset>
