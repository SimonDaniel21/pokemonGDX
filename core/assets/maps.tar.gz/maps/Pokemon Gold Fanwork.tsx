<?xml version="1.0" encoding="UTF-8"?>
<tileset name="Pokemon Gold Fanwork" tilewidth="32" tileheight="32" tilecount="2144" columns="8">
 <image source="fanwork_tilesets_gold.png" width="256" height="8600"/>
</tileset>
