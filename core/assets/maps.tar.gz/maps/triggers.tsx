<?xml version="1.0" encoding="UTF-8"?>
<tileset name="triggers" tilewidth="16" tileheight="16" tilecount="48" columns="12">
 <grid orientation="orthogonal" width="32" height="32"/>
 <image source="tiles/triggers.png" width="192" height="64"/>
</tileset>
