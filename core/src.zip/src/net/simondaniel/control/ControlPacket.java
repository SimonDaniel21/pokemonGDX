package net.simondaniel.control;

public class ControlPacket<T> {

}
