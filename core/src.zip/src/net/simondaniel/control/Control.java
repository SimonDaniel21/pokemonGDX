package net.simondaniel.control;

import net.simondaniel.entities.Entity;

public class Control{
	protected Entity e;
	
	public Control(Entity e) {
		this.e = e;
	}
}
