package net.simondaniel.pokes;

public class PokemonStats {

	int maxHP;
	int attack;
	int defense;
	int speed;
}
