package net.simondaniel.pokes;

public enum PokemonType {

	grass, electro, psychic, water, fire;
}
