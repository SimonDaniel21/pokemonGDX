package net.simondaniel.network.server;

import com.esotericsoftware.kryonet.Connection;

import net.simondaniel.network.server.Response.MovementS;

public class UserConnection extends Connection{

	public User user;

}
