package net.simondaniel.network;

public interface Network_interface {

	public void send(Object o);
}
