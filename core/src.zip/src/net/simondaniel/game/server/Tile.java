package net.simondaniel.game.server;

/**
 * the logical representation of a tile
 * @author simon
 *
 */
public class Tile {

	public boolean isSolid() {
		return false;
	}

}
