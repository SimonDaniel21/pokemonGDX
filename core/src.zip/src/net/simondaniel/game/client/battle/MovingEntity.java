package net.simondaniel.game.client.battle;

public abstract class MovingEntity extends BattleEntity{

	public abstract void move();
	public abstract void stopMove();
}
