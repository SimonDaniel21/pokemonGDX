package net.simondaniel.game.client.gfx;

import net.simondaniel.game.client.gfx.AnimationType.AnimationDirection;

public class AnimatedPikachu {

	public AnimatedPikachu(String textureAtlas, String[] animations) {
		// TODO Auto-generated constructor stub
	}
	
	private String[] getAnimationNames;{
		int types = AnimationType.values().length;
		int directions = AnimationDirection.values().length;
		String[] s = new String[types * directions];
	}

}
