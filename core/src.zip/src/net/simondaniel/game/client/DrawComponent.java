package net.simondaniel.game.client;

import net.simondaniel.game.client.gfx.PokemonAnimation;

public class DrawComponent {

	public PokemonAnimation drawable;

}
