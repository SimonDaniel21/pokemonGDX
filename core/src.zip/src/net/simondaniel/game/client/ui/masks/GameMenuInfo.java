package net.simondaniel.game.client.ui.masks;

public class GameMenuInfo extends ShowMaskInfo{

	public boolean isComplete() {
		return true;
	}

}
