package net.simondaniel.fabio;

public interface GameObject extends DrawObject, LogicObject{

}
