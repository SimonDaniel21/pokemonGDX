package net.simondaniel.fabio;

public interface LogicObject {
	
	public void update(float delta);
}
